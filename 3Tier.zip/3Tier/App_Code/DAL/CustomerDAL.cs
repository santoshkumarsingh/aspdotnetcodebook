﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using DomainModel.DAL;


/// <summary>
/// Summary description for CustomerDAL
/// </summary>
public class CustomerDAL
{


    public static void AddCustomer(CustomerBL cs)
    {
        try
        {
            using (SqlConnection con = new SqlConnection(SQLHelper.GetConnectionString()))
            {
                SqlParameter[] par = new SqlParameter[7];
                par[0] = new SqlParameter("@ID", cs.ID);
                par[0].Direction = ParameterDirection.Output;
                par[1] = new SqlParameter("@Name", cs.Name);
                par[2] = new SqlParameter("@Address", cs.Address);
                par[3] = new SqlParameter("@PhoneNumber", cs.PhoneNumber);
                par[5] = new SqlParameter("@Email", cs.Email);
                int rowNo = SQLHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "proc_InsertCustomer", par);
                cs.ID = Convert.ToInt32(par[0].Value);
            }
        }
        catch (Exception ex)
        {
            throw;
        }
    }
    public static void DeleteCustomer(CustomerBL customer)
    {
        try
        {
            using (SqlConnection con = new SqlConnection(SQLHelper.GetConnectionString()))
            {
                SqlParameter[] par = new SqlParameter[1];
                par[0] = new SqlParameter("@ID", customer.ID);
                int rowNo = SQLHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "proc_DeleteCustomer", par);
            }
        }
        catch (Exception ex)
        {
            throw;
        }
    }
    public static void GetCustomer(CustomerBL customer)
    {
        try
        {
            using (SqlConnection con = new SqlConnection(SQLHelper.GetConnectionString()))
            {
                SqlParameter[] par = new SqlParameter[1];
                par[0] = new SqlParameter("@ID", customer.ID);
                using (SqlDataReader dr = SQLHelper.ExecuteReader(con, CommandType.StoredProcedure, "OMS_Customer_SelectByCustomerID", par))
                {
                    while (dr.Read())
                    {
                        customer.Name = SQLHelper.CheckStringNull(dr["Name"]);
                        customer.PhoneNumber = SQLHelper.CheckStringNull(dr["PhoneNo"]);
                        customer.Address = SQLHelper.CheckStringNull(dr["Address"]);
                        customer.ID = SQLHelper.CheckIntNull(dr["ID"]);
                        customer.Email = SQLHelper.CheckStringNull(dr["Email"]);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            throw;
        }
    }

    public static List<CustomerBL> GetAllCustomers()
    {
        try
        {
            List<CustomerBL> cuList = new List<CustomerBL>();
            using (SqlConnection con = new SqlConnection(SQLHelper.GetConnectionString()))
            {
                using (SqlDataReader dr = SQLHelper.ExecuteReader(con, CommandType.StoredProcedure, "proc_SelectAllCustomer"))
                {
                    while (dr.Read())
                    {
                        CustomerBL customer = new CustomerBL();
                        customer.Name = SQLHelper.CheckStringNull(dr["Name"]);
                        customer.PhoneNumber = SQLHelper.CheckStringNull(dr["Phone"]);
                        customer.Address = SQLHelper.CheckStringNull(dr["Address"]);
                        customer.ID = SQLHelper.CheckIntNull(dr["ID"]);
                        cuList.Add(customer);
                    }
                }
            }
            return cuList;
        }
        catch (Exception ex)
        {
            throw;
        }
    }
}
