﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

public class ServiceType : ICurlService
{
    public string GetDate(string day, string month, string year)
    {
        return new DateTime(Convert.ToInt32(year), Convert.ToInt32(month), Convert.ToInt32(day)).ToString("dddd, MMMM dd, yyyy");
    }
   public string Greeting()
    {
        return "Hello World";
    }
   public string Save(string data)
   {
       return data + "Has been saved!";
   }
}
