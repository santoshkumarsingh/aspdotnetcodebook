﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;


[ServiceContract(SessionMode = SessionMode.NotAllowed)]
public interface ICurlService
{
    [WebGet(UriTemplate = "date/{year}/{month}/{day}", ResponseFormat = WebMessageFormat.Xml)]
    [OperationContract]
    string GetDate(string day, string month, string year);

    [WebGet(UriTemplate = "greet", ResponseFormat = WebMessageFormat.Json)]
    [OperationContract]
    string Greeting();

    [WebInvoke(Method = "POST", UriTemplate = "submit", BodyStyle = WebMessageBodyStyle.WrappedRequest, ResponseFormat = WebMessageFormat.Json, RequestFormat = WebMessageFormat.Json)]
    [OperationContract]
    string Save(string data);

}

