﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.ServiceModel.Web;
using System.ServiceModel.Activation;

[ServiceBehavior]


public class BlogService : IBlog
{


    List<Blog> _blogs = null;
    [OperationBehavior]
    public string SubmitBlock(Blog blogs)
    {
        //Process your data.
    }
}
[DataContract]
[KnownType(typeof(BlogPost))]
public class Blog
{
    [DataMember]
    public string BlogID { get; set; }
    [DataMember]
    public string Title { get; set; }
    [DataMember]
    List<BlogPost> Blogs { get; set; }
}
[DataContract]
public class BlogPost
{
    [DataMember]
    public string BlogPostID { get; set; }
    [DataMember]
    public string BlogID { get; set; }
    [DataMember]
    public string BlogContent { get; set; }
}

